#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R_MESON_VERSION "0.59.1"
#define R2_VERSION_MAJOR 5
#define R2_VERSION_MINOR 4
#define R2_VERSION_PATCH 2
#define R2_VERSION_NUMBER 50402
#define R2_VERSION_COMMIT 1
#define R2_VERSION "5.4.2"
#define R2_GITTAP "5.4.2"
#define R2_GITTIP "84e6cc6a21ec1c816d4d3eb3510d2cdc94330414"
#define R2_BIRTH "Mon 09/20/2021__ 4:55:47.20"
#endif
